setwd("C:\\Users\\MCS\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24103399_Lab_6")

#Here,random variable X has binomial distribution with n=50 and p=0.85

1-pbinom(46,50,0.85,lower.tail=TRUE)


#number of calls received in one hour
#Here,random variable Xhas poisson distribution with lambda=12

dpois(15,12)

